class User < ActiveRecord::Base
  #attr_accessible :username, :hashed_password, :salt, :profile, :bitbars
end
